<?php 
// https://cutt.ly/cwjKFXSW
?>